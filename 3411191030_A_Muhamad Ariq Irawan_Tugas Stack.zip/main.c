#include <stdio.h>
#include "stack.c"

int main(){
	printf("NIM : 3411191030\n");
	printf("NAMA : Muhamad Ariq Irawan\n");
	printf("\n");
    Stack S;
    CreateEmpty(&S);
    PrintStackInfo(S);
    printf("\n");
    Push(&S,5);
    Push(&S,2);
    Push(&S,4);
    Push(&S,2);
    Push(&S,5);
    Push(&S,9);
    Push(&S,1);
    PrintStackInfo(S);
    printf("\n%d",Pop(&S));
    printf("\n%d",Pop(&S));
    printf("\n%d",Pop(&S));
    printf("\n");
    PrintStackInfo(S);
    printf("\n");
    if(isInfoKetemu(S,4)==0){
        printf("Ada\n");
    }else{
        printf("Tidak Ada\n");
    }
    if(isInfoKetemu(S,5)==0){
        printf("Ada\n");
    }else{
        printf("Tidak Ada\n");
    }
    printf("\n%d",Pop(&S));
    printf("\n%d",Pop(&S));
    printf("\n%d",Pop(&S));
    printf("\n%d",Pop(&S));
    printf("\n%d",Pop(&S));
    printf("\n");
    printf("Element dengan nilai 5 ");
    printf("%d",CariElemenStack(S,5));
	

}
